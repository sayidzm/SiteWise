import React, { useState } from 'react';
import { 
  Home, Play, History as HistoryIcon, TrendingUp, BookOpen, Settings, MoreVertical, 
  Check, Plus, Minus, ChevronRight, Info, Timer, X, Search, Download, Upload, 
  AlertTriangle, ChevronDown, ArrowRightLeft, RefreshCw, ChevronLeft
} from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('home');
  const [activeWorkout, setActiveWorkout] = useState(false);

  const navigate = (screen: string) => setCurrentScreen(screen);

  return (
    <div className="w-full h-full min-h-screen bg-background text-text-primary flex justify-center overflow-hidden font-sans">
      <div className="w-full max-w-[390px] h-full relative flex flex-col bg-background shadow-2xl overflow-hidden">
        
        {currentScreen === 'home' && <HomeScreen onStart={() => { setActiveWorkout(true); navigate('activeWorkout'); }} onNavigate={navigate} />}
        {currentScreen === 'history' && <HistoryScreen onNavigate={navigate} />}
        {currentScreen === 'workoutDetail' && <WorkoutDetailScreen onNavigate={navigate} />}
        {currentScreen === 'progress' && <ProgressScreen onNavigate={navigate} />}
        {currentScreen === 'exerciseProgress' && <ExerciseProgressScreen onNavigate={navigate} />}
        {currentScreen === 'program' && <ProgramScreen onNavigate={navigate} />}
        {currentScreen === 'settings' && <SettingsScreen onNavigate={navigate} />}
        {currentScreen === 'workoutSummary' && <WorkoutSummaryScreen onNavigate={navigate} />}
        
        {currentScreen === 'activeWorkout' && (
          <ActiveWorkoutScreen onFinish={() => {
            setActiveWorkout(false);
            navigate('workoutSummary');
          }} onCancel={() => {
            setActiveWorkout(false);
            navigate('home');
          }} />
        )}

        {(!activeWorkout && currentScreen !== 'workoutSummary' && currentScreen !== 'settings' && currentScreen !== 'workoutDetail' && currentScreen !== 'exerciseProgress') && (
          <nav className="absolute bottom-0 w-full bg-surface/95 backdrop-blur-md border-t border-border flex justify-between items-center px-2 py-2 pb-6 z-40">
            <NavItem icon={<Home size={24} />} label="Ana Sayfa" active={currentScreen === 'home'} onClick={() => navigate('home')} />
            <NavItem icon={<HistoryIcon size={24} />} label="Geçmiş" active={currentScreen === 'history'} onClick={() => navigate('history')} />
            <NavItem icon={<Play size={32} />} label="Workout" active={currentScreen === 'activeWorkout'} highlight onClick={() => { setActiveWorkout(true); navigate('activeWorkout'); }} />
            <NavItem icon={<TrendingUp size={24} />} label="İlerleme" active={currentScreen === 'progress'} onClick={() => navigate('progress')} />
            <NavItem icon={<BookOpen size={24} />} label="Program" active={currentScreen === 'program'} onClick={() => navigate('program')} />
          </nav>
        )}
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, highlight, onClick }: { icon: React.ReactNode, label: string, active?: boolean, highlight?: boolean, onClick: () => void }) {
  if (highlight) return (
    <button onClick={onClick} className="flex flex-col items-center justify-center gap-1 min-w-[64px] min-h-[44px] -mt-6">
      <div className="w-14 h-14 rounded-full bg-primary text-primary-text flex items-center justify-center shadow-lg shadow-primary/20 border-4 border-background">
        {icon}
      </div>
    </button>
  );
  return (
    <button onClick={onClick} className={`flex flex-col items-center justify-center gap-1 min-w-[64px] min-h-[44px] ${active ? 'text-primary' : 'text-text-secondary'}`}>
      {icon}
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

function HomeScreen({ onStart, onNavigate }: any) {
  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 px-4 hide-scrollbar">
      <header className="flex justify-between items-center mb-6">
        <div><h1 className="text-[28px] font-bold text-text-primary tracking-tight">SiteWise</h1><p className="text-text-secondary text-sm">Bugün, 24 Eki</p></div>
        <button onClick={() => onNavigate('settings')} className="w-11 h-11 flex items-center justify-center text-text-secondary"><Settings size={24} /></button>
      </header>
      <div className="bg-surface rounded-[16px] p-5 mb-6 border border-border">
        <div className="mb-4"><h2 className="text-xl font-semibold mb-1">Upper Body Power</h2><p className="text-text-secondary text-[14px]">Odak: Göğüs, Sırt • 6 Egzersiz • ~55 dk</p></div>
        <button onClick={onStart} className="w-full h-[54px] bg-primary text-primary-text rounded-[14px] font-semibold text-[16px] flex items-center justify-center active:scale-[0.98] transition-transform">Workout'u başlat</button>
      </div>
      <div className="mb-8">
        <h3 className="text-[18px] font-semibold mb-3">Bu Hafta</h3>
        <div className="flex justify-between bg-surface rounded-[16px] p-4 border border-border">
          {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map((day, i) => (
            <div key={day} className={`flex flex-col items-center gap-2 ${i === 3 ? 'opacity-100' : 'opacity-40'}`}>
              <span className="text-[12px] font-medium">{day}</span>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${i === 3 ? 'bg-strong text-text-primary' : 'bg-transparent text-text-secondary'}`}>{i + 21}</div>
              {i < 3 ? <div className="w-1.5 h-1.5 rounded-full bg-success"></div> : <div className="w-1.5 h-1.5 rounded-full bg-transparent"></div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function HistoryScreen({ onNavigate }: any) { 
  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 hide-scrollbar">
      <div className="px-4 mb-4">
        <h1 className="text-[28px] font-bold text-text-primary tracking-tight mb-4">Geçmiş</h1>
        
        <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
          <button className="h-[36px] px-4 bg-primary text-primary-text font-medium rounded-full text-[14px] whitespace-nowrap">Tümü</button>
          <button className="h-[36px] px-4 bg-surface border border-border font-medium rounded-full text-[14px] text-text-secondary whitespace-nowrap">Upper</button>
          <button className="h-[36px] px-4 bg-surface border border-border font-medium rounded-full text-[14px] text-text-secondary whitespace-nowrap">Lower</button>
          <button className="h-[36px] px-4 bg-surface border border-border font-medium rounded-full text-[14px] text-text-secondary whitespace-nowrap flex items-center gap-1">30 gün <ChevronDown size={14}/></button>
        </div>
      </div>

      <div className="px-4 flex flex-col gap-6">
        <div>
          <h3 className="text-[14px] font-semibold text-text-secondary mb-3 uppercase tracking-wider">Ekim 2024</h3>
          <div className="flex flex-col gap-3">
            <div onClick={() => onNavigate('workoutDetail')} className="bg-surface border border-border rounded-[16px] p-4 active:bg-elevated transition-colors cursor-pointer">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold text-[16px]">Lower Body Hypertrophy</h4>
                <span className="bg-success/10 text-success text-[12px] font-bold px-2 py-0.5 rounded flex items-center gap-1">1 PR</span>
              </div>
              <p className="text-text-secondary text-[13px] mb-3">22 Eki, Salı</p>
              <div className="flex gap-4 text-[13px] text-text-soft font-medium tabular-nums">
                <span className="flex items-center gap-1"><Timer size={14}/> 62 dk</span>
                <span>24 set</span>
                <span>7 egzersiz</span>
              </div>
            </div>
            
            {/* Additional items omitted for brevity but represent previous implementations */}
            <div onClick={() => onNavigate('workoutDetail')} className="bg-surface border border-border rounded-[16px] p-4 active:bg-elevated transition-colors cursor-pointer">
              <div className="flex justify-between items-start mb-2"><h4 className="font-semibold text-[16px]">Upper Body Power</h4></div>
              <p className="text-text-secondary text-[13px] mb-3">20 Eki, Pazar</p>
              <div className="flex gap-4 text-[13px] text-text-soft font-medium tabular-nums"><span className="flex items-center gap-1"><Timer size={14}/> 55 dk</span><span>20 set</span><span>6 egzersiz</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  ); 
}

function WorkoutDetailScreen({ onNavigate }: any) {
  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 hide-scrollbar">
      <div className="px-4 flex items-center gap-3 mb-6">
        <button onClick={() => onNavigate('history')} className="w-10 h-10 flex items-center justify-center bg-surface border border-border rounded-full text-text-primary">
          <ChevronLeft size={20} />
        </button>
        <h1 className="text-[20px] font-bold text-text-primary tracking-tight truncate">Lower Body Hypertrophy</h1>
      </div>
      
      <div className="px-4 mb-6">
        <p className="text-text-secondary text-[14px] mb-4">22 Eki, Salı • 18:30</p>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-surface border border-border rounded-[12px] p-3 flex flex-col">
            <span className="text-[12px] text-text-secondary font-medium mb-1">Süre</span>
            <span className="text-[16px] font-bold tabular-nums">62 dk</span>
          </div>
          <div className="bg-surface border border-border rounded-[12px] p-3 flex flex-col">
            <span className="text-[12px] text-text-secondary font-medium mb-1">Tamamlanan</span>
            <span className="text-[16px] font-bold tabular-nums">24 / 24</span>
          </div>
          <div className="bg-surface border border-border rounded-[12px] p-3 flex flex-col">
            <span className="text-[12px] text-text-secondary font-medium mb-1">Egzersiz</span>
            <span className="text-[16px] font-bold tabular-nums">7</span>
          </div>
        </div>
      </div>

      <div className="px-4 flex flex-col gap-4">
        {/* Exercise Row */}
        <div className="bg-surface border border-border rounded-[16px] p-4">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h4 className="font-semibold text-[16px] mb-1">Barbell Squat</h4>
              <p className="text-[13px] text-text-secondary">Hedef: 3 × 8–10</p>
            </div>
            <span className="bg-success/10 text-success text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">PR</span>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center py-1.5 text-[14px]">
              <span className="w-8 text-text-secondary font-medium">1</span>
              <span className="flex-1 tabular-nums font-semibold">100 kg × 10</span>
              <span className="text-text-soft text-[12px]">RIR 2</span>
            </div>
            <div className="flex justify-between items-center py-1.5 text-[14px] text-success font-semibold bg-success/5 rounded px-2 -mx-2">
              <span className="w-8">2</span>
              <span className="flex-1 tabular-nums">110 kg × 8</span>
              <span className="text-[12px] font-bold">Yeni PR</span>
            </div>
            <div className="flex justify-between items-center py-1.5 text-[14px]">
              <span className="w-8 text-text-secondary font-medium">3</span>
              <span className="flex-1 tabular-nums font-semibold">110 kg × 7</span>
              <span className="text-text-soft text-[12px]">RIR 0</span>
            </div>
          </div>
          
          <div className="mt-3 p-3 bg-strong border border-border rounded-[8px]">
            <p className="text-[13px] italic text-text-secondary">"Son sette form biraz bozuldu, bir dahakine ağırlığı sabit tutalım."</p>
          </div>
        </div>
        
        {/* Another Exercise Row with Discomfort Note */}
        <div className="bg-surface border border-border rounded-[16px] p-4">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h4 className="font-semibold text-[16px] mb-1">Romanian Deadlift</h4>
              <p className="text-[13px] text-text-secondary">Hedef: 3 × 8–12</p>
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center py-1.5 text-[14px]">
              <span className="w-8 text-text-secondary font-medium">1</span>
              <span className="flex-1 tabular-nums font-semibold">90 kg × 12</span>
              <span className="text-text-soft text-[12px]">RIR 2</span>
            </div>
          </div>
          
          <div className="mt-3 p-2 bg-danger/10 border border-danger/20 rounded-[8px] flex items-center gap-2 text-danger">
            <AlertTriangle size={14} />
            <p className="text-[13px] font-semibold">Belde hafif batma hissi.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProgressScreen({ onNavigate }: any) { 
  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 px-4 hide-scrollbar">
      <h1 className="text-[28px] font-bold mb-6">İlerleme</h1>
      
      <div className="bg-surface border border-border rounded-[16px] p-4 mb-8">
        <h3 className="text-[16px] font-semibold mb-4">Bu hafta</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><p className="text-[13px] text-text-secondary font-medium mb-1">Workout</p><p className="text-xl font-bold tabular-nums">4</p></div>
          <div><p className="text-[13px] text-text-secondary font-medium mb-1">Set</p><p className="text-xl font-bold tabular-nums">52</p></div>
          <div><p className="text-[13px] text-text-secondary font-medium mb-1">PR</p><p className="text-xl font-bold tabular-nums text-success">3</p></div>
          <div><p className="text-[13px] text-text-secondary font-medium mb-1">Artış Adayı</p><p className="text-xl font-bold tabular-nums text-warning">2</p></div>
        </div>
      </div>

      <h3 className="text-[18px] font-semibold mb-4">Takip Edilen Egzersizler</h3>
      <div className="flex flex-col gap-3">
        <div onClick={() => onNavigate('exerciseProgress')} className="bg-surface border border-border rounded-[16px] p-4 flex flex-col gap-3 cursor-pointer active:bg-elevated transition-colors">
          <div className="flex justify-between items-start">
            <div><h4 className="font-semibold text-[15px]">Incline Dumbbell Press</h4><p className="text-[13px] text-text-secondary">Upper Body</p></div>
          </div>
          <div className="flex justify-between items-end mt-1">
            <div className="px-2.5 py-1 rounded-md border text-[12px] font-semibold text-text-primary bg-strong border-border">Tekrar geliştir</div>
            <div className="text-right">
              <p className="text-[11px] text-text-soft font-medium uppercase tracking-wider mb-0.5">En İyi Record</p>
              <p className="text-[14px] font-bold tabular-nums">35 kg × 8</p>
            </div>
          </div>
        </div>
        
        {/* Placeholder for others */}
        <div className="bg-surface border border-border rounded-[16px] p-4 flex flex-col gap-3 opacity-50 pointer-events-none">
          <div className="flex justify-between items-start">
            <div><h4 className="font-semibold text-[15px]">Barbell Squat</h4></div>
          </div>
          <div className="flex justify-between items-end mt-1">
            <div className="px-2.5 py-1 rounded-md border text-[12px] font-semibold text-success bg-success/10 border-success/20">Artış adayı</div>
            <div className="text-right"><p className="text-[14px] font-bold tabular-nums">120 kg × 5</p></div>
          </div>
        </div>
      </div>
    </div>
  ); 
}

function ExerciseProgressScreen({ onNavigate }: any) {
  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 hide-scrollbar">
      <div className="px-4 flex items-center gap-3 mb-6">
        <button onClick={() => onNavigate('progress')} className="w-10 h-10 flex items-center justify-center bg-surface border border-border rounded-full text-text-primary">
          <ChevronLeft size={20} />
        </button>
        <h1 className="text-[20px] font-bold text-text-primary tracking-tight truncate">Incline Dumbbell Press</h1>
      </div>
      
      <div className="px-4 mb-6">
        <p className="text-text-secondary text-[14px]">Upper Body • Hedef: 8-10 tekrar</p>
      </div>

      <div className="px-4 flex flex-col gap-6">
        <div className="bg-surface border border-border rounded-[16px] p-4">
          <h3 className="text-[14px] text-text-secondary font-semibold uppercase tracking-wider mb-3">İlerleme Durumu</h3>
          <div className="flex items-start gap-3">
            <div className="w-2 h-12 bg-primary rounded-full"></div>
            <div>
              <h4 className="font-bold text-[16px] mb-1">Aynı yükle tekrarları geliştir</h4>
              <p className="text-[13px] text-text-secondary leading-relaxed">Şu anki ağırlıkta hedef tekrar aralığının alt sınırındasın. Ağırlığı artırmadan önce hedefe ulaşmaya çalış.</p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-[18px] font-semibold mb-3">Performans Geçmişi</h3>
          <div className="flex flex-col gap-3">
            {/* Last Session */}
            <div className="bg-surface border border-border rounded-[16px] p-4">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[13px] text-text-secondary font-medium">20 Eki, Pazar</span>
                <span className="text-[12px] bg-strong px-2 py-0.5 rounded text-text-primary">3 Set</span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 1</span><span className="font-semibold tabular-nums">35 kg × 8</span></div>
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 2</span><span className="font-semibold tabular-nums">35 kg × 7</span></div>
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 3</span><span className="font-semibold tabular-nums">32.5 kg × 8</span></div>
              </div>
            </div>
            {/* Previous Session */}
            <div className="bg-surface border border-border rounded-[16px] p-4 opacity-80">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[13px] text-text-secondary font-medium">13 Eki, Pazar</span>
                <span className="text-[12px] bg-strong px-2 py-0.5 rounded text-text-primary">3 Set</span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 1</span><span className="font-semibold tabular-nums">32.5 kg × 10</span></div>
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 2</span><span className="font-semibold tabular-nums">32.5 kg × 10</span></div>
                <div className="flex justify-between text-[14px]"><span className="text-text-secondary">Set 3</span><span className="font-semibold tabular-nums">32.5 kg × 9</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProgramScreen({onNavigate}:any) { return <div className="flex-1 overflow-y-auto pb-24 pt-12 px-4 hide-scrollbar"><h1 className="text-[28px] font-bold mb-4">Program</h1></div>; }

function SettingsScreen({onNavigate}:any) { 
  const [showImportFlow, setShowImportFlow] = useState(false);
  const [importStep, setImportStep] = useState(0); // 0 = off, 1 = validation, 2 = success

  if (showImportFlow) {
    return (
      <div className="flex-1 overflow-y-auto pb-24 pt-12 px-4 hide-scrollbar">
        <div className="flex items-center gap-3 mb-8"><button onClick={() => {setShowImportFlow(false); setImportStep(0);}}><ChevronLeft size={24} /></button><h1 className="text-[24px] font-bold">İçe Aktar</h1></div>
        
        {importStep === 0 && (
          <div className="animate-in fade-in">
            <p className="text-text-secondary text-[15px] mb-6">Önceki bir JSON yedeğini seçerek verilerini geri yükle.</p>
            <button onClick={() => setImportStep(1)} className="w-full h-[54px] bg-strong border border-border rounded-[14px] font-semibold flex items-center justify-center gap-2"><Upload size={20}/> Dosya Seç</button>
          </div>
        )}

        {importStep === 1 && (
          <div className="animate-in slide-in-from-right-4">
            <div className="w-16 h-16 bg-success/10 text-success rounded-full flex items-center justify-center mb-4"><Check size={32} /></div>
            <h2 className="text-[20px] font-bold mb-2">Yedek doğrulandı</h2>
            <p className="text-[14px] text-text-secondary mb-6">İçe aktarma mevcut yerel verinin yerini alacak.</p>
            
            <div className="bg-surface border border-border rounded-[16px] p-4 flex flex-col gap-3 mb-8">
              <div className="flex justify-between"><span className="text-[14px] text-text-secondary">Tarih</span><span className="font-semibold text-[14px]">10 Eki 2024</span></div>
              <div className="flex justify-between"><span className="text-[14px] text-text-secondary">Tamamlanan Workout</span><span className="font-semibold text-[14px] tabular-nums">42</span></div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => {setShowImportFlow(false); setImportStep(0);}} className="flex-1 h-[54px] bg-background border border-border text-text-primary rounded-[14px] font-semibold text-[15px]">Vazgeç</button>
              <button onClick={() => setImportStep(2)} className="flex-1 h-[54px] bg-primary text-primary-text rounded-[14px] font-semibold text-[15px]">Yedeği aktar</button>
            </div>
          </div>
        )}

        {importStep === 2 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 flex flex-col items-center justify-center pt-12">
            <div className="w-20 h-20 bg-success text-primary-text rounded-full flex items-center justify-center mb-6"><Check size={40} strokeWidth={3}/></div>
            <h2 className="text-[24px] font-bold mb-2">Başarıyla Aktarıldı</h2>
            <p className="text-[15px] text-text-secondary text-center mb-8">Tüm verilerin başarıyla geri yüklendi.</p>
            <button onClick={() => {setShowImportFlow(false); setImportStep(0);}} className="w-full h-[54px] bg-strong border border-border rounded-[14px] font-semibold text-[16px]">Ayarlara Dön</button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto pb-24 pt-12 px-4 hide-scrollbar">
      <div className="flex items-center gap-3 mb-8"><button onClick={() => onNavigate('home')}><X size={20} /></button><h1 className="text-[24px] font-bold">Ayarlar & Veri</h1></div>
      
      <div className="mb-8">
        <h3 className="text-[14px] font-semibold text-text-secondary mb-3 uppercase tracking-wider">Veri Güvenliği</h3>
        <div className="bg-surface border border-border rounded-[16px] p-4 mb-3">
          <div className="flex justify-between mb-2"><span className="text-[14px] text-text-secondary">Tamamlanan workout</span><span className="text-[14px] font-bold tabular-nums">48</span></div>
          <div className="p-3 bg-warning/10 border border-warning/20 rounded-[8px] flex flex-col gap-1 mt-4">
            <span className="text-[13px] font-bold text-warning flex items-center gap-1"><AlertTriangle size={14}/> Son yedek: 8 gün önce</span>
            <span className="text-[12px] text-text-soft">Workout geçmişin ve ayarların JSON yedeğine kaydedilecek.</span>
          </div>
        </div>
        
        <div className="flex flex-col gap-2">
          <button className="h-[48px] bg-strong text-text-primary border border-border rounded-[12px] font-medium text-[15px] flex items-center justify-center gap-2"><Download size={18} /> Yedeği dışa aktar</button>
          <button onClick={() => setShowImportFlow(true)} className="h-[48px] bg-strong text-text-primary border border-border rounded-[12px] font-medium text-[15px] flex items-center justify-center gap-2"><Upload size={18} /> Yedekten içe aktar</button>
        </div>
      </div>
    </div>
  ); 
}

function WorkoutSummaryScreen({onNavigate}:any) { return <div className="flex-1 flex flex-col pt-16 px-4 bg-background"><h1 className="text-[24px] font-bold text-center mb-8">Workout tamamlandı</h1><button onClick={() => onNavigate('home')} className="mt-auto h-[54px] bg-primary text-primary-text rounded-[14px] font-semibold mb-8">Ana sayfa</button></div>; }

// Kept ActiveWorkoutScreen as heavily polished in the previous pass
function ActiveWorkoutScreen({ onFinish, onCancel }: { onFinish: () => void, onCancel: () => void }) {
  const [weight, setWeight] = useState(62.5);
  const [reps, setReps] = useState(8);
  const [rir, setRir] = useState<number | null>(2);
  const [restMode, setRestMode] = useState(false);
  const [showNotesSheet, setShowNotesSheet] = useState(false);
  const [showOptionsSheet, setShowOptionsSheet] = useState(false);
  const [showSubSheet, setShowSubSheet] = useState(false);
  const [showIncompleteWarning, setShowIncompleteWarning] = useState(false);
  const handleFinishRequest = () => { setShowOptionsSheet(false); setShowIncompleteWarning(true); };

  return (
    <div className="flex-1 flex flex-col h-full bg-background relative overflow-hidden">
      <header className="pt-12 pb-3 px-4 flex flex-col gap-3 bg-background z-10">
        <div className="flex justify-between items-center"><div><h2 className="text-[16px] font-semibold">Upper Body Power</h2><p className="text-sm text-text-secondary">Egzersiz 2 / 6</p></div><button onClick={() => setShowOptionsSheet(true)} className="w-11 h-11 flex items-center justify-center -mr-3 text-text-secondary"><MoreVertical size={24} /></button></div>
        <div className="w-full h-1 bg-surface rounded-full overflow-hidden"><div className="h-full bg-success w-[25%] rounded-full"></div></div>
      </header>
      <div className="flex-1 overflow-y-auto px-4 pb-32 hide-scrollbar">
        <div className="mt-2 mb-6"><h1 className="text-[26px] font-bold tracking-tight mb-1">Incline Dumbbell Press</h1><p className="text-[15px] text-text-secondary mb-2">Hedef: Üst Göğüs, Ön Omuz</p><p className="text-[15px] font-medium text-text-primary">Set 2 / 3 <span className="text-text-secondary mx-2">•</span> 8–10 tekrar <span className="text-text-secondary mx-2">•</span> RIR 1–2</p></div>
        <div className="bg-surface rounded-[12px] p-3 mb-6 border border-border flex justify-between items-center"><div className="flex flex-col gap-1"><span className="text-[13px] text-text-secondary font-semibold uppercase tracking-wider">Önceki</span><span className="text-[15px] font-semibold tabular-nums">60 kg × 8 <span className="text-text-secondary text-[13px] font-medium ml-1">RIR 2</span></span></div><button className="h-[32px] px-4 bg-strong border border-border text-[13px] font-semibold rounded-lg text-text-primary active:bg-elevated transition-colors">Öncekini kullan</button></div>
        <div className="flex flex-col gap-5 mb-8">
          <div className="flex gap-3">
            <div className="flex-1 flex flex-col gap-2"><label className="text-[13px] text-text-secondary font-semibold uppercase tracking-wider ml-1">Ağırlık (kg)</label><div className="flex items-center justify-between bg-surface rounded-[14px] border border-border p-1 h-[68px]"><button onClick={() => setWeight(w => Math.max(0, w - 2.5))} className="w-14 h-14 flex items-center justify-center rounded-[10px] bg-strong active:bg-elevated text-text-secondary"><Minus size={22} /></button><span className="text-[28px] font-bold tabular-nums tracking-tight">{weight.toFixed(1)}</span><button onClick={() => setWeight(w => w + 2.5)} className="w-14 h-14 flex items-center justify-center rounded-[10px] bg-strong active:bg-elevated text-text-secondary"><Plus size={22} /></button></div></div>
            <div className="flex-1 flex flex-col gap-2"><label className="text-[13px] text-text-secondary font-semibold uppercase tracking-wider ml-1">Tekrar</label><div className="flex items-center justify-between bg-surface rounded-[14px] border border-border p-1 h-[68px]"><button onClick={() => setReps(r => Math.max(0, r - 1))} className="w-14 h-14 flex items-center justify-center rounded-[10px] bg-strong active:bg-elevated text-text-secondary"><Minus size={22} /></button><span className="text-[28px] font-bold tabular-nums">{reps}</span><button onClick={() => setReps(r => r + 1)} className="w-14 h-14 flex items-center justify-center rounded-[10px] bg-strong active:bg-elevated text-text-secondary"><Plus size={22} /></button></div></div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-end ml-1 mr-1"><label className="text-[13px] text-text-secondary font-semibold uppercase tracking-wider">RIR (Zorluk)</label><button className="text-[12px] font-medium text-text-soft flex items-center gap-1"><Info size={14} /> Nedir?</button></div>
            <div className="flex justify-between bg-surface p-1 rounded-[14px] border border-border gap-1">{[5, 4, 3, 2, 1, 0].map((val) => (<button key={val} onClick={() => setRir(val)} className={`flex-1 h-[48px] flex items-center justify-center rounded-[10px] text-[18px] font-bold tabular-nums transition-colors ${rir === val ? 'bg-primary text-primary-text' : 'text-text-primary'}`}>{val}</button>))}</div>
          </div>
        </div>
        <div className="flex gap-2 mb-8"><button onClick={() => setShowNotesSheet(true)} className="flex-1 h-[44px] bg-surface border border-border rounded-[12px] text-[14px] font-semibold flex items-center justify-center gap-2">Not</button><button className="flex-1 h-[44px] bg-surface border border-border rounded-[12px] text-[14px] font-semibold flex items-center justify-center gap-2">Teknik</button><button onClick={() => setShowSubSheet(true)} className="flex-1 h-[44px] bg-surface border border-border rounded-[12px] text-[14px] font-semibold flex items-center justify-center gap-2">Alternatif</button></div>
        <div className="flex flex-col gap-1.5"><div className="flex items-center px-3 py-2.5 opacity-50 rounded-[12px]"><span className="w-8 text-[14px] font-bold text-text-secondary">1</span><span className="flex-1 text-[15px] tabular-nums font-medium">60 kg × 8</span><Check size={18} className="text-success" /></div><div className="flex items-center px-3 py-3.5 bg-surface border border-border rounded-[14px] shadow-sm"><span className="w-8 text-[14px] font-bold text-primary">2</span><span className="flex-1 text-[15px] tabular-nums font-semibold">62.5 kg × 8</span><span className="text-[11px] uppercase font-bold tracking-wider text-text-secondary bg-elevated px-2 py-1 rounded border border-border">Şu an</span></div><div className="flex items-center px-3 py-2.5 opacity-50 rounded-[12px]"><span className="w-8 text-[14px] font-bold text-text-secondary">3</span><span className="flex-1 text-[15px]">—</span></div></div>
        <div className="h-24"></div>
      </div>
      <div className="absolute bottom-0 w-full p-4 pb-6 bg-background/90 backdrop-blur-xl border-t border-border shadow-[0_-8px_30px_rgba(15,17,21,0.8)] z-20">
        {!restMode ? (
          <button onClick={() => setRestMode(true)} className="w-full h-[56px] bg-primary text-primary-text rounded-[14px] font-bold text-[17px] flex items-center justify-center gap-2 shadow-lg shadow-primary/10"><Check size={20} strokeWidth={3} /> Seti tamamla</button>
        ) : (
          <div className="flex items-center gap-3">
            <div className="flex-1 h-[56px] bg-surface border border-border rounded-[14px] flex items-center justify-between px-4"><div className="flex items-center gap-2 text-success"><Timer size={20} /><span className="text-[22px] font-bold tabular-nums">01:42</span></div><button className="text-[14px] font-bold text-text-primary bg-strong border border-border px-3 py-1.5 rounded-[10px]">+30 sn</button></div>
            <button onClick={() => setRestMode(false)} className="h-[56px] px-8 bg-primary text-primary-text rounded-[14px] font-bold text-[16px]">Geç</button>
          </div>
        )}
      </div>
      {showNotesSheet && (<div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex flex-col justify-end"><div className="bg-surface w-full rounded-t-[24px] border-t border-x border-border p-5 pb-8 animate-in slide-in-from-bottom-full duration-200"><div className="w-12 h-1.5 bg-strong rounded-full mx-auto mb-6"></div><div className="flex justify-between items-center mb-6"><h3 className="text-[20px] font-bold">Egzersiz Notları</h3><button onClick={() => setShowNotesSheet(false)}><X size={24}/></button></div><label className="text-[14px] font-semibold mb-2 block">Egzersiz notu</label><textarea className="w-full h-24 bg-background border border-border rounded-[12px] p-3 text-[15px] mb-4 placeholder:text-text-soft"></textarea><label className="text-[14px] font-semibold mb-2 block text-warning">Rahatsızlık</label><input type="text" className="w-full h-12 bg-background border border-border rounded-[12px] px-3 text-[15px] mb-6 placeholder:text-text-soft" placeholder="Ağrı veya rahatsızlık" /><button onClick={() => setShowNotesSheet(false)} className="w-full h-[54px] bg-primary text-primary-text rounded-[14px] font-semibold text-[16px]">Kaydet</button></div></div>)}
      {showSubSheet && (<div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex flex-col justify-end"><div className="bg-surface w-full rounded-t-[24px] border-t border-x border-border p-5 pb-8 animate-in slide-in-from-bottom-full duration-200"><div className="w-12 h-1.5 bg-strong rounded-full mx-auto mb-6"></div><div className="flex justify-between items-center mb-2"><h3 className="text-[20px] font-bold">Alternatif Egzersiz</h3><button onClick={() => setShowSubSheet(false)}><X size={24}/></button></div><p className="text-text-secondary text-[14px] mb-6">Değişiklik yalnızca bu workout için uygulanacak.</p><div className="flex flex-col gap-3 mb-6"><button className="flex items-center justify-between p-4 bg-strong border-2 border-primary rounded-[14px]"><div className="flex flex-col text-left"><span className="font-semibold">Machine Chest Press</span><span className="text-text-secondary text-[13px]">Önerilen alternatif</span></div><Check size={20} className="text-primary" /></button><button className="flex items-center justify-between p-4 bg-background border border-border rounded-[14px]"><div className="flex flex-col text-left"><span className="font-semibold text-text-primary">Smith Incline Press</span></div></button></div><div className="flex gap-3"><button onClick={() => setShowSubSheet(false)} className="flex-1 h-[54px] bg-background border border-border text-text-primary rounded-[14px] font-semibold">Vazgeç</button><button onClick={() => setShowSubSheet(false)} className="flex-[2] h-[54px] bg-primary text-primary-text rounded-[14px] font-semibold">Alternatifi kullan</button></div></div></div>)}
      {showIncompleteWarning && (<div className="absolute inset-0 bg-background/90 backdrop-blur-sm z-50 flex items-center justify-center p-4"><div className="bg-surface w-full max-w-[340px] rounded-[24px] border border-border p-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200"><div className="w-12 h-12 rounded-full bg-warning/10 text-warning flex items-center justify-center mb-4"><AlertTriangle size={24} /></div><h3 className="text-[22px] font-bold mb-2">Workout'u bitir?</h3><p className="text-text-secondary text-[15px] mb-6">3 çalışma seti tamamlanmadı. Tamamlanan setler Geçmişe kaydedilecek.</p><div className="flex flex-col gap-3"><button onClick={() => setShowIncompleteWarning(false)} className="w-full h-[54px] bg-primary text-primary-text rounded-[14px] font-bold text-[16px]">Workout'a dön</button><button onClick={onFinish} className="w-full h-[54px] bg-strong border border-border text-text-primary rounded-[14px] font-bold text-[16px]">Yine de bitir</button></div></div></div>)}
      {showOptionsSheet && (<div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex flex-col justify-end" onClick={() => setShowOptionsSheet(false)}><div className="bg-surface w-full rounded-t-[24px] border-t border-x border-border p-5 pb-8 animate-in slide-in-from-bottom-full duration-200" onClick={e => e.stopPropagation()}><div className="w-12 h-1.5 bg-strong rounded-full mx-auto mb-6"></div><div className="flex justify-between items-center mb-6"><h3 className="text-[20px] font-bold">Seçenekler</h3><button onClick={() => setShowOptionsSheet(false)}><X size={24}/></button></div><div className="flex flex-col gap-2"><button onClick={handleFinishRequest} className="w-full h-[56px] flex items-center justify-between bg-strong border border-border rounded-[14px] px-4"><span className="font-semibold text-[16px]">Workout'u bitir</span><Check size={20} className="text-success" /></button><div className="h-2"></div><button onClick={onCancel} className="w-full h-[56px] flex items-center justify-center bg-danger/10 border border-danger/20 text-danger rounded-[14px] px-4 font-semibold text-[16px]">Workout'u iptal et</button></div></div></div>)}
    </div>
  );
}
